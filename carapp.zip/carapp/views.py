from django.shortcuts import render

def index(request):
    return render(request,"carapp/index.html")
def about(request):
    return render(request,"carapp/about.html")
def services(request):
    return render(request,"carapp/service.html")
def booking(request):
    return render(request,"carapp/booking.html")
def contact(request):
    return render(request,"carapp/contact.html")